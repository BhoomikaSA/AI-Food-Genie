import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        // target: "https://internship-b7.onrender.com",
        target: "http://localhost:4000",
        changeOrigin: true,
        secure: false,
      },
    },
  },
});
